from json import dumps


def _json(data):
    return dumps(data)
