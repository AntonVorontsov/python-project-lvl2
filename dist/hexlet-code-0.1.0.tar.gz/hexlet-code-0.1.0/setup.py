# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff',
 'gendiff.formaters',
 'gendiff.formaters._json',
 'gendiff.formaters.plain',
 'gendiff.formaters.stylish',
 'gendiff.parsers',
 'gendiff.scripts']

package_data = \
{'': ['*'], 'gendiff.parsers': ['bin/*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.main:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'JSONs/YAMLs difference calculator utility',
    'long_description': None,
    'author': 'AntonVorontsov',
    'author_email': 'vorontsovanton@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
